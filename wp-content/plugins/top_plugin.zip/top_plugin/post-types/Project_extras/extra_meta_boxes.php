<?php
add_meta_box(
    'about_image_meta_box',
    'About Image',
    'display_about_image_meta_box',
    'project',
    'side',
    'default'
);
add_meta_box(
    'project_gallary_l_meta_box',
    'Project Gallary L Url',
    'display_project_gallary_l_meta_box',
    'project',
    'side',
    'default'
);
add_meta_box(
    'project_gallary_r1_meta_box',
    'Project Gallary R1',
    'display_project_gallary_r1_meta_box',
    'project',
    'side',
    'default'
);
add_meta_box(
    'project_gallary_r2_meta_box',
    'Project Gallary R2',
    'display_project_gallary_r2_meta_box',
    'project',
    'side',
    'default'
);
add_meta_box(
    'project_gallary_r3_meta_box',
    'Project Gallary R3',
    'display_project_gallary_r3_meta_box',
    'project',
    'side',
    'default'
);
add_meta_box(
    'project_gallary_r4_meta_box',
    'Project Gallary R4',
    'display_project_gallary_r4_meta_box',
    'project',
    'side',
    'default'
);
